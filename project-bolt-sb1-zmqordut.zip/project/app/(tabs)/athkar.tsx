import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Sun, Moon, Coffee, Moon as MoonIcon } from 'lucide-react-native';

interface AthkarCategory {
  id: string;
  title: string;
  icon: React.ReactNode;
  description: string;
}

const athkarCategories: AthkarCategory[] = [
  {
    id: 'morning',
    title: 'أذكار الصباح',
    icon: <Sun size={24} color="#1B5E20" />,
    description: 'الأذكار المستحبة في الصباح'
  },
  {
    id: 'evening',
    title: 'أذكار المساء',
    icon: <MoonIcon size={24} color="#1B5E20" />,
    description: 'الأذكار المستحبة في المساء'
  },
  {
    id: 'wake',
    title: 'أذكار الاستيقاظ',
    icon: <Coffee size={24} color="#1B5E20" />,
    description: 'الأذكار عند الاستيقاظ من النوم'
  },
  {
    id: 'sleep',
    title: 'أذكار النوم',
    icon: <Moon size={24} color="#1B5E20" />,
    description: 'الأذكار قبل النوم'
  },
];

export default function AthkarScreen() {
  return (
    <LinearGradient
      colors={['#E8F5E9', '#C8E6C9']}
      style={styles.container}
    >
      <View style={styles.header}>
        <Text style={styles.title}>الأذكار اليومية</Text>
        <Text style={styles.subtitle}>ذكر الله يطمئن القلوب</Text>
      </View>

      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {athkarCategories.map((category) => (
          <TouchableOpacity
            key={category.id}
            style={styles.categoryCard}
            onPress={() => {
              // Navigation will be implemented later
              console.log(`Selected category: ${category.id}`);
            }}
          >
            <View style={styles.categoryIcon}>
              {category.icon}
            </View>
            <View style={styles.categoryContent}>
              <Text style={styles.categoryTitle}>{category.title}</Text>
              <Text style={styles.categoryDescription}>{category.description}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    alignItems: 'center',
  },
  title: {
    fontFamily: 'Amiri-Bold',
    fontSize: 32,
    color: '#1B5E20',
    textAlign: 'center',
  },
  subtitle: {
    fontFamily: 'NotoNaskh',
    fontSize: 16,
    color: '#2E7D32',
    marginTop: 8,
    textAlign: 'center',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  categoryCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  categoryIcon: {
    width: 48,
    height: 48,
    backgroundColor: '#E8F5E9',
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  categoryContent: {
    flex: 1,
    marginLeft: 16,
  },
  categoryTitle: {
    fontFamily: 'Amiri-Bold',
    fontSize: 18,
    color: '#1B5E20',
    textAlign: 'right',
  },
  categoryDescription: {
    fontFamily: 'NotoNaskh',
    fontSize: 14,
    color: '#666666',
    marginTop: 4,
    textAlign: 'right',
  },
});