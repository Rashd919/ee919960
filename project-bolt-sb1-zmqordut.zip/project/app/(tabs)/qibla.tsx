import { View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function QiblaScreen() {
  return (
    <LinearGradient
      colors={['#E8F5E9', '#C8E6C9']}
      style={styles.container}
    >
      <View style={styles.header}>
        <Text style={styles.title}>اتجاه القبلة</Text>
      </View>
      <View style={styles.content}>
        <Text style={styles.message}>جاري تحميل البوصلة...</Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    alignItems: 'center',
  },
  title: {
    fontFamily: 'Amiri-Bold',
    fontSize: 32,
    color: '#1B5E20',
    textAlign: 'center',
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  message: {
    fontFamily: 'NotoNaskh',
    fontSize: 18,
    color: '#333',
    textAlign: 'center',
  },
});