import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';
import { Compass } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';

interface QiblaCompassProps {
  qiblaDirection: number;
}

export function QiblaCompass({ qiblaDirection }: QiblaCompassProps) {
  const [heading, setHeading] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (Platform.OS === 'web') {
      if ('DeviceOrientationEvent' in window) {
        const handleOrientation = (event: any) => {
          // Convert device orientation to compass heading
          const heading = event.alpha !== null ? 360 - event.alpha : null;
          setHeading(heading);
        };

        window.addEventListener('deviceorientationabsolute', handleOrientation, true);
        
        return () => {
          window.removeEventListener('deviceorientationabsolute', handleOrientation, true);
        };
      } else {
        setError('Compass not available on this device');
      }
    }
  }, []);

  const getRotationStyle = () => {
    if (heading === null) return {};
    const rotation = heading + qiblaDirection;
    return {
      transform: [{ rotate: `${rotation}deg` }],
    };
  };

  return (
    <View style={styles.container}>
      {error ? (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      ) : (
        <LinearGradient
          colors={['#1B5E20', '#2E7D32']}
          style={styles.compass}
        >
          <View style={[styles.needle, getRotationStyle()]}>
            <Compass size={150} color="#FFF" />
            <View style={styles.qiblaMarker} />
          </View>
          <Text style={styles.heading}>
            {heading !== null ? `${Math.round(heading)}°` : 'Calibrating...'}
          </Text>
        </LinearGradient>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  compass: {
    width: 250,
    height: 250,
    borderRadius: 125,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  needle: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  qiblaMarker: {
    position: 'absolute',
    width: 4,
    height: 20,
    backgroundColor: '#FFD700',
    top: 0,
  },
  heading: {
    color: '#FFF',
    fontSize: 24,
    fontFamily: 'NotoNaskh-Bold',
    marginTop: 20,
  },
  errorContainer: {
    padding: 20,
    backgroundColor: '#FEE2E2',
    borderRadius: 8,
  },
  errorText: {
    color: '#991B1B',
    fontSize: 16,
    fontFamily: 'NotoNaskh',
    textAlign: 'center',
  },
});