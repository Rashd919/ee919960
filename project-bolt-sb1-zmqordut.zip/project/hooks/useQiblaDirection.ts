import { useState, useEffect } from 'react';
import * as Location from 'expo-location';

interface QiblaCalculation {
  qiblaDirection: number | null;
  error: string | null;
  loading: boolean;
}

const KAABA_COORDS = {
  latitude: 21.422487,
  longitude: 39.826206,
};

export function useQiblaDirection(): QiblaCalculation {
  const [state, setState] = useState<QiblaCalculation>({
    qiblaDirection: null,
    error: null,
    loading: true,
  });

  useEffect(() => {
    async function getQiblaDirection() {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        
        if (status !== 'granted') {
          setState({
            qiblaDirection: null,
            error: 'Location permission denied',
            loading: false,
          });
          return;
        }

        const location = await Location.getCurrentPositionAsync({});
        const { latitude, longitude } = location.coords;

        // Calculate Qibla direction using the Spherical Law of Cosines
        const φ1 = toRadians(latitude);
        const φ2 = toRadians(KAABA_COORDS.latitude);
        const Δλ = toRadians(KAABA_COORDS.longitude - longitude);

        const y = Math.sin(Δλ);
        const x = Math.cos(φ1) * Math.tan(φ2) - Math.sin(φ1) * Math.cos(Δλ);
        const qiblaDirection = toDegrees(Math.atan2(y, x));

        setState({
          qiblaDirection: (qiblaDirection + 360) % 360,
          error: null,
          loading: false,
        });
      } catch (error) {
        setState({
          qiblaDirection: null,
          error: 'Failed to calculate Qibla direction',
          loading: false,
        });
      }
    }

    getQiblaDirection();
  }, []);

  return state;
}

function toRadians(degrees: number): number {
  return degrees * (Math.PI / 180);
}

function toDegrees(radians: number): number {
  return radians * (180 / Math.PI);
}